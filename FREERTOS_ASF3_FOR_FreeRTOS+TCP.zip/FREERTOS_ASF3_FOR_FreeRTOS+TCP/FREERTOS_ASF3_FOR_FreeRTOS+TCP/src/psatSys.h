/*
 * psatSys.h
 *
 * Created: 4/4/2020 12:02:06 AM
 *  Author: justi
 */ 


#ifndef PSATSYS_H_
#define PSATSYS_H_

#include <asf.h>
#include <string.h>



//Error severity defs
#define PSAT_SEVERITY_WARNING			0x20
#define PSAT_SEVERITY_SELF_RECOVERABLE	0x40
#define PSAT_SEVERITY_USER_RECOVERABLE	0x60
#define PSAT_SEVERITY_FATAL				0xF0

//Indicate the buffer size of the errorLog
#define PSAT_ERROR_BUF_SIZE	32

//Error severity defs
#define PSAT_SEVERITY_WARNING			0x20
#define PSAT_SEVERITY_SELF_RECOVERABLE	0x40
#define PSAT_SEVERITY_USER_RECOVERABLE	0x60
#define PSAT_SEVERITY_FATAL				0xF0

//Error defs used in logic
#define PSAT_ERR_NOT_FOUND		0xFF
#define PSAT_ERR_LOG_FULL		0xFF

#define PSAT_SYS_KEY			0xFE

//Unit flags 
#define UNIT_PMIC_IDX			0x01	//General Power related error
#define UNIT_KILL_IDX			0x02	//Indicates all motors in unit are killed
#define UNIT_TMC_IDX			0x04	//Motion Control blocked by error
#define UNIT_CLIMATE_IDX		0x08	//Ventilation failure
#define UNIT_COMM_IDX			0x10	//General bus errors
#define UNIT_ENABLE_IDX			0x20	//At least one motor is enabled
#define UNIT_LED_ENABLE			0x40	//Enable LED indication
#define UNIT_BUZZ_ENABLE		0x80	//Enable Buzzer indication

//Unit states
#define UNIT_STATE_NORMAL		0x00
#define UNIT_STATE_READY		0x01
#define UNIT_STATE_KILL			0x02
#define UNIT_STATE_ERR			0x03


/************************************************************************/
/* Comm structures to describe subsystems and relevant data             */
/************************************************************************/
#define VENT_OPEN_IDX	0x01
#define VENT_FOUND_IDX	0x02
#define VENT_DET_IDX	0x04
#define VENT_DIS_IDX	0x08
#define VENT_AUTO_IDX	0x10

//Generic object for fans and vents
struct _psat_fan{
	float	RPM;			//RPM from tach of fan
	U8		ldpwmVal;		//PWM value being sent to fan
	U8		setPWMVal;		//Current PWM value from fan
	U8		statFlags;
	U8		cmdFlags;
	};
//Generic object for IMU data
struct _psat_imu{
	//Accel. Data
	float ax;
	float ay;
	float az;
	//Gyro data
	float gx;
	float gy;
	float gz;
	//Degree offsets
	float dx;
	float dy;
	float dz;
	bool found;
	bool dataGood;
	};
//Generic object for environmental sensing data
struct _psat_esd{
	float temp;
	float hum;
	float pres;
	bool found;
	};

//Rotor Data structure
struct _rotor_data{
	float tmpu;
	float tlsr;
	float Vin;
	float V12;
	float V5;
	U8  cmdFlags;
	U8 statFlags;
	};

//LCU data structure
struct _lcu_data{
	float Vdrv;
	float Vin;
	float Vmain;
	float Vbckup;
	float V12;
	float V5;
	float current;
	float power;
	float tmpu;
	U8 cmdFlags;
	U8 statFlags;
	};

//Generic object for a motor
struct _psat_motor{
	float ldTarget;		//Target to load, provided by CLI 
	float target;		//The current set target of TMC
	float position;		//The current position of a TMC
	float speed;
	U8 state;			//Current state of a TMC
	U8 statFlags;		//Current status flags for a TMC
	U8 cmdFlags;		//Command bytes holding user directives for TMC
	U8 tmcFlags;		//COMM flags from tmc chip
	U8 profileSel;		//TMC profile
	U8 key;
	U16 sg2Val;			//SG2 value from DRV_CONF
	};
	
//Structs for a psat unit
struct _psat_lower_unit{
	U8						statFlags;	//unit flags
	U8						cmdFlags;	//command flags
	U8						unitState;	//Unit state
	
	struct _psat_motor		mtr;		//Motor Data		
	struct _psat_fan		intake;		//Vent Data
	struct _psat_fan		exhaust;
	struct _lcu_data		data;		//Unit Data
	struct _psat_esd		envDat;		//Environmental data
	struct _psat_imu		imuDat;		//IMU data
	};

//Structs for a psat unit
struct _psat_rotor_unit{
	//Packet headers
	U8		somFlag;
	U8		IDFlag;
	//Payload
	U8						unitFlags;		//unit flags
	U8						cmdFlags;		//command flags
	U8						unitState;		//Unit state
	
	struct _psat_motor		mtr1;			
	struct _psat_motor		mtr2;		
	struct _psat_fan		intake;
	struct _psat_fan		exhaust;
	struct _rotor_data		data;
	
	struct _psat_esd		rotorEnv;		//Environmental data
	struct _psat_esd		exteriorEnv;	//outside conditions
	struct _psat_imu		imuDat1;		//IMU data
	struct _psat_imu		imuDat2;
	
	//packet headers
	U8	   chkFlag;
	U8	   eomFlag;
	};

SemaphoreHandle_t rotorMutex;

//contains global logic variables shared between the rotor, lower unit, and master(s)
struct _psat_sys{
	U8 globalStatFlags;		//Global state flags
	U8 globalCMDFlags;		//Global command flags
	U8 unitState;			//Global System state
	U8 padKey;				//Padding byte used for decoding data
	struct _psat_lower_unit lowerUnit;
	struct _psat_rotor_unit rotorUnit;
}PSAT, cliPSAT;	//The global PSAT structure and the copy used for comm



SemaphoreHandle_t psatMutex;
//pointers referenced by threads to import data 
struct _psat_rotor_unit * Rotorptr;			//Pointer placed at base of rotor comm rx buffer
struct _psat_rotor_unit RotorTxBuf;
struct _psat_sys		* PSATptr;			//Pointer placed at base of CLI rx buffer
struct _psat_motor		azMtr;
struct _psat_motor		mtr1;
struct _psat_motor		mtr2;

U8 azCmdFlags;
float azTar;

//Structure stashes in flash containing vent and motor logic 
struct _psat_stash{
	U8 globalFlags;		//Global state flags
	bool sysKill;		//Flag to kill all motors
	
	struct _psat_lower_unit lowerUnit;
	struct _psat_rotor_unit rotorUnit;
	}PSATstash;




#endif /* PSATDEFS_H_ */